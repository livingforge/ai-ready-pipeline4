"""ARP: editable document authorities, provenance and Excel writeback."""

__version__ = "4.0.0.dev0"
