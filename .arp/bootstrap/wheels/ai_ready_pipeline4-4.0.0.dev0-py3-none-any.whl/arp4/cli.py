"""ARP document management CLI."""
from __future__ import annotations
import argparse
from .documents.cli import register
from .specifications.cli import register as register_specifications


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="arp4", description="文書管理・仕様整理・設計書生成・Excel書き戻し")
    subparsers = parser.add_subparsers(dest="command", required=True)
    register(subparsers)
    register_specifications(subparsers)
    args = parser.parse_args(argv)
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
