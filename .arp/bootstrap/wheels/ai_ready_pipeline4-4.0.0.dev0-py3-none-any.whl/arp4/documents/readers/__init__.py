"""Stateless extraction of Office, PDF, text and source files."""
