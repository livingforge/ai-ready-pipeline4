"""Diagnostics returned by source readers."""
from typing import NamedTuple


class Finding(NamedTuple):
    level: str
    code: str
    target: str
    message: str

    def render(self) -> str:
        return f"[{self.level}] {self.code} {self.target}: {self.message}"
