"""In-memory extraction data; persisted through document contracts."""
from dataclasses import dataclass, field

EXT = ".md"

@dataclass
class Chunk:
    """パース結果 1 か所。**表かテキストかは提示上の都合**であって意味ではない。"""

    anchor: str
    at: str = ""
    heading: str = ""
    #: 表として出すとき。1 行目も含めて**そのまま**（見出し行を決めつけない）。
    rows: list[list[str]] = field(default_factory=list)
    #: テキストとして出すとき。``(セル番地, 値)``。
    cells: list[tuple[str, str]] = field(default_factory=list)
    #: **原文をそのまま**出すとき。Markdown の資料はこれを使う ―― 原本が既に
    #: 読める形なので、表や箇条書きに組み直すところが 1 つも無い。組み直すと
    #: 入れ子の箇条書き・コードブロック・引用が平らになり、**資料に書いて
    #: あったことが消える**（Excel は「セルの面」を紙に寄せ直す必要があるので
    #: :attr:`rows` / :attr:`cells` を使う ―― 出自で必要な作業が違う）。
    text: str = ""

@dataclass
class Doc:
    """パース結果 1 ファイル。"""

    title: str
    source: str
    chunks: list[Chunk] = field(default_factory=list)
    #: **機械が読めなかったもの**の申告（図形・画像）。アンカーは持たない
    #: ―― 出典にはならないが、「資料に無い」と「読めていない」を読み手が
    #: 取り違えないために必ず出す。
    notes: list[str] = field(default_factory=list)
