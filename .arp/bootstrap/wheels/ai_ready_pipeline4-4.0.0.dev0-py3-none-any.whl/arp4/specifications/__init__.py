"""Typed specifications derived from versioned document evidence."""
