"""CLI for specification organization and deterministic deliverables."""
import json
from pathlib import Path

from arp4.documents.contracts import DocumentError
from .contracts import SCHEMAS
from .render import DELIVERABLES
from .workspace import Workspace


def register(subparsers):
    parser = subparsers.add_parser("spec", help="仕様整理・検証・設計書生成")
    actions = parser.add_subparsers(dest="spec_action", required=True)
    for name, help_text in {
        "init": "入力の固定版と仕様整理用ファイルを作る", "sources": "固定した入力単位を表示",
        "refresh": "入力を更新し、既存仕様を維持する", "check": "仕様・出典・入力更新・レビューを検証",
        "review": "現在の仕様をレビュー済みにする", "build": "設計書を生成する",
        "schema": "仕様のJSON Schemaを表示", "kinds": "生成する成果物を表示",
    }.items():
        command = actions.add_parser(name, help=help_text)
        command.add_argument("--root", type=Path, default=Path.cwd())
        command.set_defaults(handler=run)
        if name not in ("schema", "kinds"):
            command.add_argument("spec_id")
        if name in ("init", "refresh"):
            command.add_argument("--document", action="append", default=[], help="採用済み文書ID（複数指定可）")
            command.add_argument("--proposal", action="append", default=[], help="機械抽出を読む候補名（複数指定可）")
        if name == "init":
            command.add_argument("--title", required=True)
        if name == "review":
            command.add_argument("--reviewer", required=True)
        if name == "build":
            command.add_argument("--draft", action="store_true")
        if name == "check":
            command.add_argument("--require-reviewed", action="store_true")


def run(args) -> int:
    try:
        action = args.spec_action
        if action == "schema":
            print(json.dumps(SCHEMAS["specification"], ensure_ascii=False, indent=2))
            return 0
        if action == "kinds":
            for name, (title, _) in DELIVERABLES.items():
                print(f"{name}: {title}")
            print("issues: 課題管理表\ntraceability: トレーサビリティ")
            return 0
        workspace = Workspace(args.root)
        if action == "init":
            print(workspace.create(args.spec_id, args.title, documents=args.document, proposals=args.proposal))
        elif action == "refresh":
            print(workspace.refresh(args.spec_id, documents=args.document, proposals=args.proposal))
        elif action == "sources":
            print(json.dumps(workspace.load(args.spec_id)[1], ensure_ascii=False, indent=2))
        elif action == "check":
            result = workspace.inspect(args.spec_id)
            print(json.dumps({key: result[key] for key in ("revision", "pending", "uncovered", "reviewed", "ready")}, ensure_ascii=False, indent=2))
            return 1 if result["pending"] or (args.require_reviewed and not result["reviewed"]) else 0
        elif action == "review":
            print(json.dumps(workspace.review(args.spec_id, args.reviewer), ensure_ascii=False, indent=2))
        elif action == "build":
            print(workspace.build(args.spec_id, draft=args.draft) / "index.md")
        return 0
    except (DocumentError, OSError, ValueError) as exc:
        print(f"error: {exc}")
        return 1
