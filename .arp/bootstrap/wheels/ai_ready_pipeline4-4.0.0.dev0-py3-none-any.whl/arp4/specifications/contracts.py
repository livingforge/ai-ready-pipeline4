"""Strict, independent contracts for organized specifications."""
from jsonschema import Draft202012Validator

from arp4.documents.contracts import (
    DocumentError, HASH, ID, NONEMPTY, SOURCE, VERSION, array, obj,
)

WORDS = {**NONEMPTY, "pattern": r"\S"}
REF = obj({"document": ID, "unit": ID})
DETAILS = {
    "requirement": obj({"category": {"enum": ["functional", "nonfunctional", "constraint"]},
                        "acceptance": WORDS}),
    "function": obj({"inputs": array(WORDS), "outputs": array(WORDS), "rules": array(WORDS)}),
    "entity": obj({"physical_name": WORDS}),
    "field": obj({"physical_name": WORDS, "data_type": WORDS, "nullable": {"type": "boolean"},
                  "primary_key": {"type": "boolean"}}),
    "screen": obj({"route": WORDS, "fields": array(WORDS), "actions": array(WORDS)}),
    "interface": obj({"method": WORDS, "path": WORDS, "request": WORDS,
                      "response": WORDS, "errors": array(WORDS)}),
    "process": obj({"steps": {**array(WORDS), "minItems": 1}}),
    "test": obj({"preconditions": array(WORDS), "steps": {**array(WORDS), "minItems": 1},
                 "expected": WORDS}),
    "decision": obj({"alternatives": array(WORDS), "consequence": WORDS}),
    "component": obj({"technology": WORDS, "responsibilities": array(WORDS), "interfaces": array(WORDS)}),
    "program": obj({"module": WORDS, "language": WORDS, "inputs": array(WORDS), "outputs": array(WORDS),
                    "steps": {**array(WORDS), "minItems": 1}, "errors": array(WORDS)}),
    "test_plan": obj({"level": WORDS, "scope": array(WORDS), "environment": WORDS,
                      "entry_criteria": WORDS, "exit_criteria": WORDS}),
    "test_result": obj({"outcome": {"enum": ["passed", "failed", "blocked", "not_run"]},
                        "actual": WORDS, "executed_at": WORDS, "executor": WORDS, "evidence": WORDS}),
    "operation": obj({"trigger": WORDS, "steps": {**array(WORDS), "minItems": 1},
                      "monitoring": WORDS, "recovery": WORDS}),
    "deployment": obj({"environment": WORDS, "steps": {**array(WORDS), "minItems": 1},
                       "verification": WORDS, "rollback": WORDS}),
    "migration": obj({"source": WORDS, "destination": WORDS, "mapping": array(WORDS),
                      "validation": WORDS, "rollback": WORDS}),
    "security": obj({"asset": WORDS, "threat": WORDS, "control": WORDS, "verification": WORDS}),
    "project_task": obj({"owner": WORDS, "deliverables": array(WORDS), "schedule": WORDS,
                         "completion_criteria": WORDS}),
}
ITEM = obj({"id": ID, "kind": {"enum": list(DETAILS)}, "title": WORDS, "statement": WORDS,
            "status": {"enum": ["draft", "confirmed"]}, "basis": {"enum": ["source", "inferred"]},
            "sources": array(REF), "rationale": {"type": "string"}, "details": {"type": "object"}})
ITEM["allOf"] = [
    {"if": {"properties": {"kind": {"const": name}}}, "then": {"properties": {"details": detail}}}
    for name, detail in DETAILS.items()
]
RELATION = obj({"from": ID, "to": ID,
                "kind": {"enum": ["satisfies", "contains", "uses", "verifies", "implements", "result_of", "depends_on"]}})
INPUT = obj({"document": ID, "kind": {"enum": ["extraction", "document"]}, "snapshot": HASH})
ISSUE = obj({"id": ID, "title": WORDS, "description": WORDS, "sources": array(REF),
             "status": {"enum": ["open", "resolved"]}, "resolution": {"type": "string"}})
SCHEMAS = {
    "specification": obj({"schema_version": VERSION, "id": ID, "title": WORDS,
                          "inputs": {**array(INPUT), "minItems": 1}, "items": array(ITEM),
                          "relations": array(RELATION), "issues": array(ISSUE),
                          "exclusions": array(obj({"source": REF, "reason": WORDS,
                                                   "status": {"enum": ["draft", "confirmed"]}}))}),
    "input": obj({"schema_version": VERSION, "document": ID,
                  "kind": {"enum": ["extraction", "document"]}, "revision": HASH,
                  "source": SOURCE, "warnings": array({"type": "string"}),
                  "units": {**array(obj({"id": ID, "location": {"type": "object"},
                                         "label": WORDS, "data": {}})), "minItems": 1}}),
    "review": obj({"schema_version": VERSION, "specification": HASH, "reviewer": WORDS}),
}


def validate(kind: str, value: object) -> None:
    errors = sorted(Draft202012Validator(SCHEMAS[kind]).iter_errors(value), key=lambda e: str(list(e.path)))
    if errors:
        raise DocumentError("; ".join(f"{kind}/{'/'.join(map(str, e.path))}: {e.message}" for e in errors))
