"""Pure graph, provenance and completeness validation; no filesystem access."""
from dataclasses import dataclass

from arp4.documents.contracts import DocumentError
from .contracts import validate


@dataclass(frozen=True)
class Assessment:
    pending: tuple[str, ...]
    uncovered: tuple[tuple[str, str], ...]

    @property
    def ready(self) -> bool:
        return not self.pending


def assess(spec: dict, inputs: list[dict]) -> Assessment:
    validate("specification", spec)
    documents = [i["document"] for i in spec["inputs"]]
    if len(set(documents)) != len(documents):
        raise DocumentError("duplicate input document")
    if set(documents) != {i["document"] for i in inputs} or len(inputs) != len(documents):
        raise DocumentError("input set does not match specification")
    units = set()
    for source in inputs:
        validate("input", source)
        for unit in source["units"]:
            key = source["document"], unit["id"]
            if key in units:
                raise DocumentError(f"duplicate source unit: {key}")
            units.add(key)

    def references(refs):
        found = [(r["document"], r["unit"]) for r in refs]
        if len(set(found)) != len(found) or any(r not in units for r in found):
            raise DocumentError(f"missing or duplicate source reference: {found}")
        return set(found)

    items, covered, excluded, pending = {}, set(), set(), []
    for item in spec["items"]:
        if item["id"] in items:
            raise DocumentError(f"duplicate item ID: {item['id']}")
        items[item["id"]] = item
        if item["basis"] == "source" and not item["sources"]:
            raise DocumentError(f"source-based item needs evidence: {item['id']}")
        if item["basis"] == "inferred" and not item["rationale"].strip():
            raise DocumentError(f"inferred item needs rationale: {item['id']}")
        covered |= references(item["sources"])
        if item["status"] == "draft":
            pending.append(f"草稿項目: {item['id']}")

    edges, parents = set(), {}
    for relation in spec["relations"]:
        start, end, kind = relation["from"], relation["to"], relation["kind"]
        key = start, end, kind
        if start not in items or end not in items or start == end or key in edges:
            raise DocumentError(f"invalid or duplicate relation: {key}")
        edges.add(key)
        a, b = items[start]["kind"], items[end]["kind"]
        allowed = {
            "satisfies": a in ("function", "screen", "interface", "process", "security", "component") and b == "requirement",
            "contains": a == "entity" and b == "field",
            "uses": a in ("function", "process", "screen", "interface", "program", "component") and b in ("entity", "interface", "screen", "component"),
            "verifies": a == "test" and b in ("requirement", "function", "interface", "process", "screen", "program", "security"),
            "implements": a == "program" and b in ("function", "process", "interface"),
            "result_of": a == "test_result" and b == "test",
            "depends_on": True,
        }
        if not allowed[kind]:
            raise DocumentError(f"relation kind does not match endpoints: {key} ({a}, {b})")
        if kind == "contains":
            if end in parents:
                raise DocumentError(f"field belongs to multiple entities: {end}")
            parents[end] = start
    physical, entities = set(), set()
    for item in items.values():
        if item["kind"] == "entity":
            name = item["details"]["physical_name"].casefold()
            if name in entities:
                raise DocumentError(f"duplicate entity physical name: {name}")
            entities.add(name)
        if item["kind"] == "field":
            if item["id"] not in parents:
                raise DocumentError(f"field needs exactly one entity: {item['id']}")
            key = parents[item["id"]], item["details"]["physical_name"].casefold()
            if key in physical:
                raise DocumentError(f"duplicate field physical name: {key}")
            physical.add(key)
            if item["details"]["primary_key"] and item["details"]["nullable"]:
                raise DocumentError(f"primary key cannot be nullable: {item['id']}")
        if item["kind"] == "test_result":
            targets = [r for r in spec["relations"] if r["from"] == item["id"] and r["kind"] == "result_of"]
            if len(targets) != 1:
                raise DocumentError(f"test result needs exactly one test: {item['id']}")

    issue_ids = set()
    for issue in spec["issues"]:
        if issue["id"] in issue_ids:
            raise DocumentError(f"duplicate issue ID: {issue['id']}")
        issue_ids.add(issue["id"])
        references(issue["sources"])
        if issue["status"] == "open":
            pending.append(f"未解決事項: {issue['id']} {issue['title']}")
        elif not issue["resolution"].strip():
            raise DocumentError(f"resolved issue needs resolution: {issue['id']}")
    for exclusion in spec["exclusions"]:
        refs = references([exclusion["source"]])
        if refs & (covered | excluded):
            raise DocumentError("a source unit cannot be both used and excluded or excluded twice")
        excluded |= refs
        if exclusion["status"] == "draft":
            pending.append(f"対象外理由の再確認が必要: {exclusion['source']['document']}/{exclusion['source']['unit']}")
    uncovered = tuple(sorted(units - covered - excluded))
    pending.extend(f"未整理入力: {doc}/{unit}" for doc, unit in uncovered)
    if not items:
        pending.append("仕様項目がありません")
    return Assessment(tuple(pending), uncovered)
