"""Deterministic Markdown projections of a validated specification."""
import html
import json
import re

from arp4.documents.contracts import digest, encoded

RENDER_VERSION = "1"
DELIVERABLES = {
    "project-plan": ("プロジェクト計画書", ("project_task",)),
    "requirements": ("要件定義書", ("requirement",)),
    "basic-design": ("基本設計書", ("component", "function", "entity", "screen", "interface", "security")),
    "detailed-design": ("詳細設計書", ("process", "interface", "program", "decision")),
    "table-design": ("テーブル定義書", ("entity", "field")),
    "screen-design": ("画面・帳票項目設計書", ("screen",)),
    "interface-design": ("インターフェース設計書", ("interface",)),
    "program-design": ("プログラム設計書", ("program",)),
    "test-plan": ("テスト計画書", ("test_plan",)),
    "test-specification": ("テスト仕様書", ("test",)),
    "test-results": ("テスト結果報告書", ("test_result",)),
    "migration-design": ("移行設計書", ("migration",)),
    "deployment-plan": ("リリース手順書", ("deployment",)),
    "operations-manual": ("運用設計・手順書", ("operation",)),
    "security-design": ("セキュリティ設計書", ("security",)),
    "decisions": ("設計判断記録", ("decision",)),
}
LABELS = {
    "requirement": "要件", "function": "機能", "entity": "テーブル", "field": "項目",
    "screen": "画面・帳票", "interface": "インターフェース", "process": "処理",
    "test": "テストケース", "decision": "設計判断", "component": "構成要素",
    "program": "プログラム", "test_plan": "テスト計画", "test_result": "実行結果",
    "operation": "運用", "deployment": "リリース", "migration": "移行",
    "security": "セキュリティ", "project_task": "計画作業",
    "category": "分類", "acceptance": "受入条件", "inputs": "入力", "outputs": "出力",
    "rules": "業務規則", "physical_name": "物理名", "data_type": "データ型",
    "nullable": "NULL許可", "primary_key": "主キー", "route": "画面URL・識別子",
    "fields": "表示・入力項目", "actions": "操作", "method": "方式・メソッド", "path": "接続先",
    "request": "要求", "response": "応答", "errors": "例外・エラー", "steps": "処理手順",
    "preconditions": "前提条件", "expected": "期待結果", "alternatives": "比較した選択肢",
    "consequence": "影響", "technology": "技術", "responsibilities": "責務", "interfaces": "接続",
    "module": "モジュール", "language": "言語", "level": "テストレベル", "scope": "対象範囲",
    "environment": "環境", "entry_criteria": "開始条件", "exit_criteria": "終了条件",
    "outcome": "判定", "actual": "実測結果", "executed_at": "実施日時", "executor": "実施者",
    "evidence": "実行証跡", "trigger": "実施契機", "monitoring": "監視", "recovery": "復旧",
    "verification": "確認方法", "rollback": "切り戻し", "source": "移行元", "destination": "移行先",
    "mapping": "変換規則", "validation": "照合方法", "asset": "保護対象", "threat": "脅威",
    "control": "対策", "owner": "担当", "deliverables": "成果物", "schedule": "予定",
    "completion_criteria": "完了条件",
}
RELATIONS = {"satisfies": "充足", "contains": "所属項目", "uses": "利用", "verifies": "検証",
             "implements": "実装", "result_of": "実行対象", "depends_on": "依存"}


def text(value) -> str:
    if isinstance(value, bool):
        return "はい" if value else "いいえ"
    value = html.escape(str(value), quote=False).replace("\r", "")
    return re.sub(r"([\\`*_{}\[\]()#+.!|>~-])", r"\\\1", value).replace("\n", "<br>")


def fence(value) -> str:
    body = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)
    marker = "`" * max(3, max((len(m[0]) + 1 for m in re.finditer(r"`+", body)), default=3))
    return f"{marker}json\n{body}\n{marker}"


def source_anchor(document: str, unit: str) -> str:
    return "source-" + digest(encoded([document, unit]))[:24]


def source_links(refs: list[dict]) -> str:
    return ", ".join(f"[{text(r['document'])}/{text(r['unit'])}](sources.md#{source_anchor(r['document'], r['unit'])})"
                     for r in refs) or "出典なし（判断理由を参照）"


def render(spec: dict, inputs: list[dict], revision: str, pending: list[str], *, draft: bool) -> dict[str, bytes]:
    """Render all deliverables without mutating inputs or reading the filesystem."""
    files = {}
    mode = "草稿・未承認" if draft else "レビュー済み仕様から生成"
    header = f"> {mode} / 仕様版: `{revision}`\n\n"
    items = sorted(spec["items"], key=lambda i: i["id"])
    by_id = {item["id"]: item for item in items}
    relations = sorted(spec["relations"], key=lambda r: (r["from"], r["kind"], r["to"]))

    def item_link(item_id):
        kind = by_id[item_id]["kind"]
        choices = [(len(kinds), name) for name, (_, kinds) in DELIVERABLES.items() if kind in kinds]
        name = min(choices)[1]
        return f"[{text(item_id)}]({name}.md#item-{item_id})"

    def save(name, title, body):
        files[name + ".md"] = (f"# {text(title)} — {text(spec['title'])}\n\n" + header + body.rstrip() + "\n").encode("utf-8")

    def item_body(item):
        lines = [f'<a id="item-{item["id"]}"></a>', f"### {text(item['id'])} {text(item['title'])}", "",
                 text(item["statement"]), "", "状態: " + ("確定" if item["status"] == "confirmed" else "草稿"), ""]
        lines += ["根拠: " + ("原本・文書" if item["basis"] == "source" else "推論・設計判断"), "",
                  "出典: " + source_links(item["sources"]), ""]
        if item["rationale"]:
            lines += ["判断理由: " + text(item["rationale"]), ""]
        for key, value in sorted(item["details"].items()):
            lines += [f"**{LABELS[key]}**", ""]
            if isinstance(value, list):
                lines += ([f"{index}. {text(v)}" for index, v in enumerate(value, 1)] if value else ["記載なし"])
            else:
                lines += [text(value)]
            lines += [""]
        linked = [r for r in relations if r["from"] == item["id"] or r["to"] == item["id"]]
        if linked:
            lines += ["関連仕様:", ""] + [f"- {item_link(r['from'])} → {RELATIONS[r['kind']]} → {item_link(r['to'])}" for r in linked] + [""]
        return "\n".join(lines)

    absent = []
    for name, (title, kinds) in DELIVERABLES.items():
        sections = []
        if not any(i["kind"] in kinds for i in items):
            absent.append(title)
        for kind in kinds:
            selected = [i for i in items if i["kind"] == kind]
            sections += ["## " + LABELS[kind], ""]
            sections += [item_body(i) for i in selected] if selected else ["該当する仕様は未定義です。", ""]
        if name == "table-design":
            for entity in (i for i in items if i["kind"] == "entity"):
                members = {r["to"] for r in relations if r["kind"] == "contains" and r["from"] == entity["id"]}
                sections += [f"## {text(entity['details']['physical_name'])} の項目一覧", "",
                             "| ID | 物理名 | データ型 | NULL許可 | 主キー |", "| --- | --- | --- | --- | --- |"]
                for field in (i for i in items if i["id"] in members):
                    detail = field["details"]
                    sections.append("| " + " | ".join(text(v) for v in (field["id"], detail["physical_name"], detail["data_type"], detail["nullable"], detail["primary_key"])) + " |")
                if not members:
                    sections.append("| — | 項目未定義 | — | — | — |")
                sections += [""]
        save(name, title, "\n".join(sections))

    lines = []
    for issue in sorted(spec["issues"], key=lambda i: i["id"]):
        lines += [f"## {text(issue['id'])} {text(issue['title'])}", "", text(issue["description"]), "",
                  "状態: " + ("未解決" if issue["status"] == "open" else "解決済み"), "",
                  "解決内容: " + (text(issue["resolution"]) or "未記載"), "", source_links(issue["sources"]), ""]
    save("issues", "課題管理表", "\n".join(lines) or "登録された課題はありません。")

    lines = ["## 仕様と出典", "", "| ID | 種別 | 名称 | 出典 |", "| --- | --- | --- | --- |"]
    lines += [f"| {item_link(i['id'])} | {LABELS[i['kind']]} | {text(i['title'])} | {source_links(i['sources'])} |" for i in items]
    lines += ["", "## 仕様間の関係", "", "| 元 | 関係 | 先 |", "| --- | --- | --- |"]
    lines += [f"| {item_link(r['from'])} | {RELATIONS[r['kind']]} | {item_link(r['to'])} |" for r in relations]
    lines += ["", "## 対象外にした入力", ""]
    lines += ["- " + source_links([e["source"]]) + ": " + text(e["reason"]) + ("（再確認が必要）" if e["status"] == "draft" else "") for e in spec["exclusions"]]
    save("traceability", "トレーサビリティ", "\n".join(lines))

    lines = []
    for source in sorted(inputs, key=lambda s: s["document"]):
        lines += ["## " + text(source["document"]), "", f"入力種別: {source['kind']} / 固定版: `{source['revision']}`", ""]
        lines += ["- 抽出時の申告: " + text(w) for w in source["warnings"]] + [""]
        for unit in source["units"]:
            lines += [f'<a id="{source_anchor(source["document"], unit["id"])}"></a>',
                      "### " + text(unit["label"]), "", f"ID: `{unit['id']}`", "", fence(unit["data"]), ""]
    save("sources", "固定した入力と出典", "\n".join(lines))

    lines = ["## 成果物", ""]
    lines += [f"- [{title}]({name}.md)" for name, (title, _) in DELIVERABLES.items()]
    lines += ["- [課題管理表](issues.md)", "- [トレーサビリティ](traceability.md)", "- [入力と出典](sources.md)", "",
              "## 検証状況", ""]
    lines += ["- " + text(p) for p in pending] if pending else ["登録された仕様と入力の機械検証を通過しています。"]
    lines += ["", "## 該当仕様が未定義の成果物", ""]
    lines += ["- " + title for title in absent] if absent else ["全種類に仕様が登録されています。"]
    lines += ["", "レビューと機械検証は、仕様の意味の正しさやシステム全体の網羅性を自動保証しません。"]
    save("index", "成果物一覧", "\n".join(lines))
    return files
