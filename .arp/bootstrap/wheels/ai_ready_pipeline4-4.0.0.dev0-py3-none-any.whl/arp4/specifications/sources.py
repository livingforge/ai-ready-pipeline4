"""Adapter from document storage to immutable, addressable specification inputs."""
from arp4.documents.contracts import DocumentError, digest, encoded, read, under
from arp4.documents.store import Store
from .contracts import validate


def capture(store: Store, name: str, *, proposal: bool = False) -> dict:
    directory = store.proposal(name) if proposal else store.document(name)
    if proposal:
        meta = read(directory / "document.yml", "document")
        extraction = store.extraction(meta["extraction"])
        if extraction["source"] != meta["source"] or extraction["document_id"] != meta["document_id"]:
            raise DocumentError("proposal/extraction identity mismatch")
        original = under(store.root, meta["source"]["snapshot"])
        if not original.is_relative_to(store.evidence / "sources") or digest(original.read_bytes()) != meta["source"]["sha256"]:
            raise DocumentError("original evidence integrity failure")
    else:
        result = store.inspect(directory)
        extraction, meta = result["extraction"], result["meta"]
    units = []

    def unit(location, label, data):
        units.append({"id": "u-" + digest(encoded(location))[:24],
                      "location": location, "label": label, "data": data})

    warnings = [f"{f['code']}: {f['message']}" for f in extraction["findings"]]
    if proposal:
        for page in extraction["pages"]:
            for chunk in page["chunks"]:
                unit({"page": page["id"], "block": chunk["id"]},
                     page["title"] + " / " + chunk["id"], chunk)
            if page["notes"] or not page["chunks"]:
                unit({"page": page["id"], "notes": True}, page["title"] + " / 注記", page["notes"])
        for sheet in extraction["sheets"]:
            for cell in sheet["cells"]:
                unit({"sheet": sheet["name"], "cell": cell["address"]},
                     sheet["name"] + "!" + cell["address"], cell)
    else:
        for page in result["pages"]:
            lines = page.path.read_text(encoding="utf-8").splitlines()
            blocks = sorted(page.blocks.items(), key=lambda pair: pair[1])
            for index, (block, start) in enumerate(blocks):
                end = blocks[index + 1][1] - 1 if index + 1 < len(blocks) else len(lines)
                mappings = [m for m in result["mappings"] if m["page"] == page.id and m["block"] == block]
                unit({"page": page.id, "block": block}, page.id + " / " + block,
                     {"text": "\n".join(lines[start - 1:end]), "mappings": mappings})
    if not units:
        raise DocumentError("input contains no extractable units")
    snapshot = {"schema_version": "1", "document": meta["document_id"],
                "kind": "extraction" if proposal else "document",
                "revision": meta["extraction"] if proposal else result["content"],
                "source": meta["source"], "warnings": warnings,
                "units": sorted(units, key=lambda unit: unit["id"])}
    validate("input", snapshot)
    return snapshot


def drift(store: Store, snapshot: dict) -> list[str]:
    """Report changed inputs; the fixed input remains available for draft rendering."""
    problems = []
    source = under(store.root, snapshot["source"]["path"])
    if not source.is_file() or digest(source.read_bytes()) != snapshot["source"]["sha256"]:
        problems.append(f"原本が更新または削除されています: {snapshot['document']}")
    if snapshot["kind"] == "document":
        try:
            current = store.inspect(store.document(snapshot["document"]))
            if current["content"] != snapshot["revision"]:
                problems.append(f"文書正本が更新されています: {snapshot['document']}")
            if not current["reviewed"]:
                problems.append(f"入力文書正本が未レビューです: {snapshot['document']}")
        except (DocumentError, OSError) as exc:
            problems.append(f"入力文書正本を検証できません: {snapshot['document']}: {exc}")
    return problems
