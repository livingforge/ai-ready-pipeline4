"""Project-local specification lifecycle; rendering and validation stay pure."""
import os
from pathlib import Path
import tempfile

from arp4.documents.contracts import DocumentError, digest, encoded, identifier, read, under, write
from arp4.documents.store import Store
from . import sources
from .contracts import validate
from .model import assess
from .render import RENDER_VERSION, render

GUIDE = """# 仕様整理

spec.yml が編集対象です。inputs の固定版は変更せず、`arp4 spec sources <id> --root <project>`
で入力単位を読みます。`arp4 spec schema` が仕様全体の契約です。

- items に型付き仕様を作り、意味の変わらないIDを付ける。statusはdraftから始める。
- sourcesは入力のdocument/unitを指す。原本と解釈を区別し、推論はbasis: inferredとrationaleを記録する。
- entitiesの項目はkind: field、関係はentityからfieldへのcontainsで表す。
- 要件と機能はsatisfies、プログラムと機能はimplements、テストはverifies、実行結果はresult_ofで接続する。
- 未解決の矛盾はissuesに残す。捨てる入力はexclusionsに具体的理由とstatusを記録する。
- 機械が読み取れなかったもの、数値、否定、条件を黙って落とさない。テスト結果は実施証跡がある場合のみ記録する。
- 同じ事実を複数の成果物へ手で複製しない。生成器が仕様型から必要な文書へ投影する。
- `arp4 spec check <id>`で検証し、`arp4 spec build <id> --draft`で草稿を見る。
- レビュー権限がある場合のみ`arp4 spec review <id> --reviewer <担当>`を実行する。
- 正式出力は`arp4 spec build <id>`。入力更新時は`arp4 spec refresh`し、差分を整理して再レビューする。

これらのコマンドには`--root <project>`を付ける。LLM呼び出しは内蔵していない。
"""


def immutable(path: Path, body: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("xb") as stream:
            stream.write(body)
    except FileExistsError:
        if path.read_bytes() != body:
            raise DocumentError(f"immutable evidence changed: {path}")


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".arp-write-", dir=path.parent) as temp:
        staged = Path(temp) / path.name
        write(staged, value)
        os.replace(staged, path)


class Workspace:
    def __init__(self, root: Path):
        self.documents = Store(root)
        self.root = self.documents.root
        self.base = under(self.documents.directory, "specifications")
        self.evidence = self.documents.evidence

    def directory(self, spec_id: str) -> Path:
        return under(self.base, identifier(spec_id))

    def _capture(self, documents: list[str], proposals: list[str]) -> list[dict]:
        snapshots = [sources.capture(self.documents, name) for name in documents]
        snapshots += [sources.capture(self.documents, name, proposal=True) for name in proposals]
        if not snapshots:
            raise DocumentError("select at least one --document or --proposal")
        ids = [s["document"] for s in snapshots]
        if len(set(ids)) != len(ids):
            raise DocumentError("select one input version per document")
        result = []
        for snapshot in sorted(snapshots, key=lambda s: s["document"]):
            key = digest(encoded(snapshot))
            immutable(under(self.evidence, f"spec-inputs/{key}.json"), encoded(snapshot))
            result.append({"document": snapshot["document"], "kind": snapshot["kind"], "snapshot": key})
        return result

    def create(self, spec_id: str, title: str, *, documents=(), proposals=()) -> Path:
        directory = self.directory(spec_id)
        if directory.exists():
            raise DocumentError("specification already exists; edit it or choose a new ID")
        spec = {"schema_version": "1", "id": spec_id, "title": title,
                "inputs": self._capture(documents, proposals), "items": [], "relations": [],
                "issues": [], "exclusions": []}
        validate("specification", spec)
        self.base.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".arp-spec-", dir=self.base) as temp:
            staged = Path(temp) / "specification"
            staged.mkdir()
            write(staged / "spec.yml", spec)
            (staged / "organize.md").write_text(GUIDE, encoding="utf-8", newline="\n")
            staged.rename(directory)
        return directory

    def load(self, spec_id: str) -> tuple[dict, list[dict]]:
        spec = read(self.directory(spec_id) / "spec.yml")
        validate("specification", spec)
        if spec["id"] != spec_id:
            raise DocumentError("specification ID does not match its directory")
        inputs = []
        for ref in spec["inputs"]:
            identifier(ref["document"])
            snapshot = read(under(self.evidence, f"spec-inputs/{ref['snapshot']}.json"))
            validate("input", snapshot)
            if digest(encoded(snapshot)) != ref["snapshot"]:
                raise DocumentError("input snapshot integrity failure")
            if snapshot["document"] != ref["document"] or snapshot["kind"] != ref["kind"]:
                raise DocumentError("input snapshot identity mismatch")
            original = under(self.root, snapshot["source"]["snapshot"])
            if not original.is_relative_to(self.evidence / "sources") or digest(original.read_bytes()) != snapshot["source"]["sha256"]:
                raise DocumentError("original evidence integrity failure")
            if snapshot["kind"] == "extraction":
                extraction = self.documents.extraction(snapshot["revision"])
                if extraction["document_id"] != snapshot["document"] or extraction["source"] != snapshot["source"]:
                    raise DocumentError("extraction identity mismatch")
            inputs.append(snapshot)
        return spec, inputs

    def inspect(self, spec_id: str) -> dict:
        spec, inputs = self.load(spec_id)
        assessment = assess(spec, inputs)
        pending = list(assessment.pending)
        for snapshot in inputs:
            pending += sources.drift(self.documents, snapshot)
        revision = digest(encoded(spec))
        review_path = self.directory(spec_id) / "review.json"
        review = None
        if review_path.exists():
            review = read(review_path)
            validate("review", review)
        reviewed = review is not None and review["specification"] == revision
        if reviewed:
            archive = read(under(self.evidence, f"specifications/{revision}.json"))
            if encoded(archive) != encoded(spec):
                raise DocumentError("reviewed specification evidence changed")
            proof = read(under(self.evidence, f"spec-reviews/{digest(encoded(review))}.json"))
            if proof != review:
                raise DocumentError("review evidence changed")
        return {"spec": spec, "inputs": inputs, "revision": revision,
                "pending": sorted(pending), "uncovered": list(assessment.uncovered),
                "reviewed": reviewed, "review": review if reviewed else None,
                "ready": not pending and reviewed}

    def refresh(self, spec_id: str, *, documents=(), proposals=()) -> Path:
        path = self.directory(spec_id) / "spec.yml"
        before = path.read_bytes()
        spec, previous = self.load(spec_id)
        replacements = self._capture(documents, proposals)
        changed, report = set(), []
        old = {s["document"]: s for s in previous}
        for ref in replacements:
            snapshot = read(under(self.evidence, f"spec-inputs/{ref['snapshot']}.json"))
            before_units = {u["id"]: u for u in old.get(ref["document"], {}).get("units", [])}
            after_units = {u["id"]: u for u in snapshot["units"]}
            removed = sorted(before_units.keys() - after_units.keys())
            added = sorted(after_units.keys() - before_units.keys())
            updated = sorted(k for k in before_units.keys() & after_units.keys() if before_units[k] != after_units[k])
            changed.update((ref["document"], k) for k in removed + updated)
            report.append({"document": ref["document"], "added": added, "removed": removed, "changed": updated})
        def affected(refs):
            return any((r["document"], r["unit"]) in changed for r in refs)
        affected_items = {i["id"] for i in spec["items"] if affected(i["sources"])}
        # Propagate impact from a changed dependency to its dependents.
        while True:
            propagated = {r["from"] for r in spec["relations"] if r["to"] in affected_items}
            propagated |= {r["to"] for r in spec["relations"] if r["kind"] == "contains" and r["from"] in affected_items}
            if propagated <= affected_items:
                break
            affected_items |= propagated
        for item in spec["items"]:
            if item["id"] in affected_items:
                item["status"] = "draft"
        for exclusion in spec["exclusions"]:
            if affected([exclusion["source"]]):
                exclusion["status"] = "draft"
        for issue in spec["issues"]:
            if affected(issue["sources"]):
                issue["status"] = "open"
        inputs = {i["document"]: i for i in spec["inputs"]}
        inputs.update({i["document"]: i for i in replacements})
        spec["inputs"] = [inputs[key] for key in sorted(inputs)]
        validate("specification", spec)
        if path.read_bytes() != before:
            raise DocumentError("specification changed during refresh; retry")
        # Existing items survive; missing references are reported by check, never silently removed.
        atomic_json(path, spec)
        atomic_json(self.directory(spec_id) / "refresh.json", {"inputs": report, "affected_items": sorted(affected_items)})
        return path

    def review(self, spec_id: str, reviewer: str) -> dict:
        result = self.inspect(spec_id)
        if result["pending"]:
            raise DocumentError("review blocked: " + "; ".join(result["pending"]))
        review = {"schema_version": "1", "specification": result["revision"], "reviewer": reviewer}
        validate("review", review)
        immutable(under(self.evidence, f"specifications/{result['revision']}.json"), encoded(result["spec"]))
        immutable(under(self.evidence, f"spec-reviews/{digest(encoded(review))}.json"), encoded(review))
        atomic_json(self.directory(spec_id) / "review.json", review)
        return review

    def build(self, spec_id: str, *, draft: bool = False) -> Path:
        result = self.inspect(spec_id)
        if not draft and not result["ready"]:
            raise DocumentError("formal output requires a current review and complete inputs: " + "; ".join(result["pending"]))
        files = render(result["spec"], result["inputs"], result["revision"], result["pending"], draft=draft)
        files["specification.json"] = encoded(result["spec"])
        for source in result["inputs"]:
            files[f"inputs/{source['document']}.json"] = encoded(source)
        manifest = {"schema_version": "1", "specification": result["revision"], "renderer": RENDER_VERSION,
                    "draft": draft, "review": None if draft else result["review"],
                    "pending": result["pending"], "files": {name: digest(body) for name, body in sorted(files.items())}}
        output_hash = digest(encoded(manifest))
        files["manifest.json"] = encoded(manifest)
        destination = under(self.root, f".arp/out/specifications/{identifier(spec_id)}/{output_hash}")
        if destination.exists():
            actual = {p.relative_to(destination).as_posix(): p.read_bytes() for p in destination.rglob("*") if p.is_file()}
            if any(p.is_symlink() for p in destination.rglob("*")) or actual != files:
                raise DocumentError("generated output changed; preserve edits and choose a separate project/output location")
            return destination
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".arp-build-", dir=destination.parent) as temp:
            staged = Path(temp) / "output"
            staged.mkdir()
            for name, body in files.items():
                path = under(staged, name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(body)
            current = self.inspect(spec_id)
            if (current["revision"], current["pending"], current["review"]) != (result["revision"], result["pending"], result["review"]):
                raise DocumentError("specification or inputs changed during generation; retry")
            staged.rename(destination)
        return destination
